import java.time.LocalDate;

public class TestCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    JavaBeanActivity act = new JavaBeanActivity() ;
    	act.setCustomerNo(101); 
    	act.setFirstName("Harry");
    	act.setLastname("john");
    	//act.setEmail("harry.john@gmail.com");
    	act.setDob(LocalDate.of(1991, 11, 11));
    	act.setGender(Gender.Male);
    	act.setPhone(123);
    	
    	System.out.println("Customer No: "+act.getCustomerNo());
    	System.out.println("First Name:"+act.getFirstName());
    	System.out.println("LastName :"+act.getLastname());
    	//System.out.println("Email: "+act.getEmail());
    	System.out.println("Phone :"+act.getPhone());
    	System.out.println("Gender :"+act.getGender());
    	System.out.println("DOB:"+act.getDob());
    	
    
    		}

}
