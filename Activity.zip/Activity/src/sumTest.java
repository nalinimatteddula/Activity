
public class sumTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a =20;
		int b =30;
		int add = a+b;
		System.out.println("sum of two numbers is :"+add);
	}
     
}
