import java.time.LocalDate;

public class JavaBeanActivity {
	private int CustomerNo;
	private String FirstName;
	private String Lastname;
	private int phone;
	Gender gender;
	LocalDate dob;
	
   public int getCustomerNo() {
		return CustomerNo;
	}

	public void setCustomerNo(int customerNo) {
		CustomerNo = customerNo;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastname() {
		return Lastname;
	}

	public void setLastname(String lastname) {
		Lastname = lastname;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	//public String getEmail() {
		//return email;
	//}

	//public void setEmail(String email) {
		//this.email = email;
//	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

public JavaBeanActivity() {
	   
   }
}
